import React from 'react'

const Assessment = () => {
  return (
    <div>Assessment</div>
  )
}

export default Assessment